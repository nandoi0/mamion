import './footer.css';

const Footer = () => {
    return (<div className='footer'>
        <h4>© 2022</h4>
        <h5>Fernando Iribe</h5>
        </div> );
};

export default Footer;